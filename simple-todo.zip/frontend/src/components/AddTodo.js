import React, { useState } from 'react';
import axios from 'axios';

function AddTodo() {
  const [title, setTitle] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    await axios.post('http://localhost:8080/api/todos', { title, completed: false });
    setTitle('');
    window.location.reload();
  };

  return (
    <form onSubmit={submit} className="mb-3">
      <div className="input-group">
        <input className="form-control" placeholder="Enter todo title" value={title} onChange={e => setTitle(e.target.value)} />
        <button className="btn btn-primary" type="submit">Add</button>
      </div>
    </form>
  );
}

export default AddTodo;
