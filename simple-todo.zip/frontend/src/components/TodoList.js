import React, { useEffect, useState } from 'react';
import axios from 'axios';

function TodoList() {
  const [todos, setTodos] = useState([]);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const res = await axios.get('http://localhost:8080/api/todos');
    setTodos(res.data);
  };

  const toggle = async (t) => {
    await axios.put(`http://localhost:8080/api/todos/${t.id}`, { ...t, completed: !t.completed });
    load();
  };

  const remove = async (id) => {
    await axios.delete(`http://localhost:8080/api/todos/${id}`);
    load();
  };

  return (
    <div>
      <ul className="list-group">
        {todos.map(t => (
          <li key={t.id} className="list-group-item d-flex justify-content-between align-items-center">
            <div>
              <input type="checkbox" checked={t.completed} onChange={() => toggle(t)} />{' '}
              <span style={{ textDecoration: t.completed ? 'line-through' : 'none' }}>{t.title}</span>
            </div>
            <div>
              <button className="btn btn-danger btn-sm" onClick={() => remove(t.id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodoList;
