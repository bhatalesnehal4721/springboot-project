# Simple To-Do App (React + Spring Boot)

## Backend (Spring Boot)
- Java 17+, Maven
- Configure MySQL in `backend/src/main/resources/application.properties`
  - Create database: `CREATE DATABASE tododb;`
  - Update username/password

Run backend:
```
cd backend
mvn spring-boot:run
```

## Frontend (React)
```
cd frontend
npm install
npm start
```

Frontend runs on http://localhost:3000 and backend on http://localhost:8080
